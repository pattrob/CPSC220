
/**
 * Enumeration class SocialYear - write a description of the enum class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public enum SocialYear
{
    FRESHMAN, SOPHOMORE, JUNIOR, SENIOR
}
