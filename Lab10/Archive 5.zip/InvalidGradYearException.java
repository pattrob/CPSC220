
/**
 * Write a description of class InvalidGradYearException here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class InvalidGradYearException extends Exception
{
    
    public InvalidGradYearException(String m)
    {
        super(m);
        
    }

}